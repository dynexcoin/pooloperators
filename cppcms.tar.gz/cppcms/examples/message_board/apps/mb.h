#ifndef MB_H
#define MB_H

#include <cppcms/application.h>

namespace apps {

class mb : public cppcms::application {
public:

	mb(cppcms::service &s);

};


}


#endif
