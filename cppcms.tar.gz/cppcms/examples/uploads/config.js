{
	"service" : {
		"api" : "http",
		"port" : 8080
	},
	"http" : {
		"script" : "/uploader"
	},
	"file_server" : {
		"enable" : true,
		"listing" : true,
		"document_root" : "."
	},
}
