{
	"encoding" : "UTF-8",
	"tags" : {
		"opening_and_closing" : [ 
			"b", "i", "tt",
			"strong", "em", 
			"blockquote" ,
			"a"
		],
		"stand_alone" : [ "br", "hr" ]
	},
	"attributes" : [
		{
			"tags" : [ "a" ],
			"attributes" : [ "href" ],
			"type" : "uri"
		}
	]
}

