{
	"filters" : {
		//
		// Basic profile for example for blog comments
		//
		"profile" : "comment_profile.js"
		// 

		
		//
		// Profile for simple TinyMCE configuration with rich content.
		//
		// To use download TinyMCE and extract in this diectory,
		//
		// "tinymce" : true,
		// "profile" : "tinymce_profile.js",
		//

	},
	"service" : {
		"api" : "http",
	},
	"http" : {
		"script" : "/xss"
	},
	"file_server" : {
		"enable" : true
	}
}

