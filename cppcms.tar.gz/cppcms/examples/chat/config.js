{
	"service" : {
		"api" : "http",
		"port" : 8080
	},
	"http" : {
		"script" : "/chat"
	},
	"file_server" : {
		"enable" : true,
		"document_root" : "."
	},

}

