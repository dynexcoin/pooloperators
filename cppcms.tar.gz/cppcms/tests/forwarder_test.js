
{
	"service" : {
		"api" : "scgi",
		"port" : 8081,
		"ip" : "127.0.0.1",
		"disable_global_exit_handling" : true
	}
}
