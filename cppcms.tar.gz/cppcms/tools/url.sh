#!/usr/bin/env bash

#REPO_URL=svn://svn.code.sf.net/p/cppcms/code/framework/branches/v1.0_fixes
REPO_URL=http://svn.code.sf.net/p/cppcms/code/framework/trunk


