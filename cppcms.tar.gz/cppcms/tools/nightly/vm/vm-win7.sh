#!/bin/bash

export VM="Windows 7"
export VM_ID=win7
export VM_PORT=2240
export VM_EXE='\msys64\usr\bin\'
export VM_MSYS_EXE='/c/msys64/usr/bin/'
export VM_SCP=sftp
export VM_WAIT=45
export VM_PING="cmd /c echo ok"
export VM_OS=windows
