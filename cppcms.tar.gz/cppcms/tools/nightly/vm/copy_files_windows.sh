#!/bin/bash

sftp -p
