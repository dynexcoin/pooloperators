#!/bin/bash

export VM="localhost"
export VM_ID=localhost
export VM_PORT=22
export VM_WAIT=0
export VM_PING="echo"
export VM_OS=unix
export VM_TAR=tar
