#!/bin/bash

export VM="FreeBSD 11.1"
export VM_ID=freebsd
export VM_PORT=2242
export VM_WAIT=60
export VM_PING="echo"
export VM_OS=unix
export VM_TAR=tar
