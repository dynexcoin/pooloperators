#!/bin/bash

export VM="Solaris11"
export VM_ID=solaris
export VM_PORT=2250
export VM_WAIT=120
export VM_PING="echo"
export VM_OS=unix
export VM_TAR=/usr/gnu/bin/tar
